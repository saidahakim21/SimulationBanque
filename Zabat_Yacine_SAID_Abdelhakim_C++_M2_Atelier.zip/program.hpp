/******************************
 * created by Yacine ZABAT
 ******************************/

#ifndef __PROGRAM__HPP
#define __PROGRAM__HPP

#include "Simulation.hpp"
#include <stdio.h>     /* for printf */
#include <stdlib.h>    /* for exit */
#include <getopt.h>
void setCashierServiceTime(double**, int);

#endif
