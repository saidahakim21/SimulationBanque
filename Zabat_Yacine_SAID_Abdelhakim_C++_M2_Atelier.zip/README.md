# SimulationBanque

Réalisé par : 
- Yacine Zabat
- Abdelhakim SAID

example de lancement : 

```
    ./program.out -nc 3 -st 1 1.2 1.4 -dp 1000 -tm 30
```

contact mail : 
- zabatyacine32@gmail.com
-  ahakim.said@gmail.com

